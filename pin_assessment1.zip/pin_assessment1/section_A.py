import random

# Open the txt file
# TODO REPLACE THIS WITH YOUR FILE PATH
f = open('/home/pin/pin-assessment1/words.txt', 'r')

# Store each line to a list of words
unprocessed_words = f.readlines()


# Create a list for the useable words
words = []

for word in unprocessed_words:
    # Convert the word to lowercase and clean it
    word = word.lower().strip()

    # Ignore words containing an apostrophe
    if "'" in word:
        continue

    # If the word is 4 letters long, add it to our new list of words to use
    if len(word) == 4:
        words.append(word)


# Create a list for unique words
unique_words = []

for word in words:
    # If it's not in the unique words list, add it, so we get each word only once
    if word not in unique_words:
        unique_words.append(word)

# Print the number of unique four letter words
print(f'There are {len(unique_words)} unique, four letter words in the text file\n')


# Create a dictionary for the word endings
word_endings = {}

# To calculate how many words each ending has
for word in unique_words:
    # Extract the last two letters of the word
    word_end = word[-2:]

    # If the ending isn't in the dictionary, add it and give a value of 1
    if word_endings.get(word_end) is None:
        word_endings[word_end] = 1

    # If it is in the list, increase its dictionary entry value by 1
    else:
        word_endings[word_end] += 1


# Create a list for the popular word endings
popular_endings = []

# Print a title for the ending frequencies
print('| Ending | Frequency |')

# Run through the dictionary and extract the ending and its frequency
for end, freq in word_endings.items():
    # If that frequency is 30 or over
    if freq > 29:
        # Print the ending and the frequency for the user
        print(f'|{end:^8}|{freq:^11}|')

        # Add the ending to a list of only our popular endings
        popular_endings.append(end)


# Create a list for our final words
final_words = []

# We want to pick a word for each ending in our popular endings list
for ending in popular_endings:
    # Create a temporary list into which we're going to put words with that ending
    endings_pick = []

    for word in unique_words:
        # If the word ends with our current ending, add it to our temporary list
        if word.endswith(ending):
            endings_pick.append(word)

    # Choose a random word from our temp list, and add it to our final stimuli list
    chosen_word = random.choice(endings_pick)
    final_words.append(chosen_word)

# We print the length of the list
print(f'\nThere are {len(final_words)} words in our stimuli list:')
# And its contents
print(final_words)

# Close the text file
f.close()
